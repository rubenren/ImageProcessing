display('Problem 1a.i:');
display('see pdf');

display('Problem 1a.ii:');
display('see pdf');

display('Problem 1a.iii:');
display('see pdf');

display('Problem 1a.iv:');
display('see pdf');

display('Problem 1a.v:');
display('see pdf');

display('Problem 2a:');
hw5_dwt;

display('Problem 2b:');
hw5_edges;

display('Problem 2c:');
hw5_nr;